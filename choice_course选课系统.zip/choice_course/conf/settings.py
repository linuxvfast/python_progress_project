__author__ = 'progress'

import os,sys
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
db_DIR = os.path.join(base_dir,'db')
admin_dir = os.path.join(base_dir,'db','admin')
teacher_dir = os.path.join(base_dir,'db','teacher')
student_dir = os.path.join(base_dir,'db','student')
course_dir = os.path.join(base_dir,'db','course')
classes_dir = os.path.join(base_dir,'db','classes')
school_dir = os.path.join(base_dir,'db','school')
course_to_teacher_dir = os.path.join(base_dir,'db','course_to_teacher')
class_record_dir = os.path.join(base_dir,'db','class_record')
class_grade_dir = os.path.join(base_dir,'db','class_grade')