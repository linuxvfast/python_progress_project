__author__ = 'progress'

import json

date = {'name':'admin','password':'admin'}
with open('admin.json','w',encoding='utf-8') as wf :
    json.dump(date,wf)