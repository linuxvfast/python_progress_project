__author__ = 'progress'

import logging
from conf import setting

def logger(log_type):

    #创建日志
    logger = logging.getLogger(log_type)  #定义日志文件
    logger.setLevel(setting.LOG_LEVEL)   #定义日志级别


    # create console handler and set level to debug
    ch = logging.StreamHandler()
    ch.setLevel(setting.LOG_LEVEL)

    # 设置文件handler并设置日志级别为警告
    log_file = "%s/log/%s" %(setting.base_dir, setting.LOG_TYPES[log_type])
    fh = logging.FileHandler(log_file)
    fh.setLevel(setting.LOG_LEVEL)

    # 设置日志的显示格式
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    # 设置ch和fh的日志格式
    ch.setFormatter(formatter)
    fh.setFormatter(formatter)

    # 添加日志到ch和fh
    logger.addHandler(ch)
    logger.addHandler(fh)

    return logger


