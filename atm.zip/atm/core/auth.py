__author__ = 'progress'
from conf import setting
import os,time,json

def acc_auth(account,password):
    '''
    用户认证函数
    :param account:信用卡认证码
    :param password: 信用卡认证密码
    :return: 如果密码认证通过，返回当前的信用卡信息，否则返回None
    '''
    account_file = '%s/%s.json'%(setting.file_dir,account)
    if os.path.isfile(account_file):
        with open(account_file, 'r',encoding='utf-8') as f:
            account_data = json.load(f)
            # print(account_data)
            if account_data['password'] == password:
                exp_time_stamp = time.mktime(time.strptime(account_data['expire_date'], "%Y-%m-%d"))
                # print(exp_time_stamp)
                if time.time() > exp_time_stamp:
                    print(
                        "账号 [%s] 已经过期,请重新申请" % account)
                else:  # passed the authentication
                    return account_data
            else:
                print("账号id或者密码错误")
    else:
        print("Account [%s] does not exist!" % account)

def acc_login(user_data,log_obj):
    '''
    用户登录认证
    :param user_data: 用户信息,仅保存在内存中
    :param log_obj: 登录日志
    :return:
    '''
    retry_count = 0
    while user_data['is_authenticated'] is not True and retry_count < 3:
        account = input("请输入用户id:").strip()
        password = input("请输入密码:").strip()
        auth = acc_auth(account, password)
        if auth:  # not None means passed the authentication
            user_data['is_authenticated'] = True
            user_data['account_id'] = account
            return auth
        retry_count += 1
    else:
        log_obj.error("account [%s] too many login attempts" % account)
        exit()