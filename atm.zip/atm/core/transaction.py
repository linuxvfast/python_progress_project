__author__ = 'progress'
import json
from conf import setting

def make_transaction(log_obj,acc_data,tran_type,amount,**kwargs):
    '''
    所有用户的交易函数
    :param log_obj: 创建的日志文件
    :param acc_data:用户信息
    :param tran_type:交易类型
    :param amount:用户需要取出的钱
    :param kwargs:
    :return:
    '''
    amount = float(amount)

    if tran_type in setting.TRANSACTION_TYPE:
        interest = amount * setting.TRANSACTION_TYPE[tran_type]['interest']
        old_balance = acc_data['balance']
        if setting.TRANSACTION_TYPE[tran_type]['action'] == 'plus':
            new_balance = old_balance + amount + interest
        elif setting.TRANSACTION_TYPE[tran_type]['action'] == 'minus':
            new_balance = old_balance - amount - interest

            # check credit
            if new_balance < 0:
                print('''\033[31;1mYour credit [%s] is not enough for this transaction [-%s], your current balance is
                    [%s]''' % (acc_data['credit'], (amount + interest), old_balance))
                return
        acc_data['balance'] = new_balance
        with open('%s/%s.json'%(setting.file_dir,acc_data['id']),'w',encoding='utf-8') as w:
            json.dump(acc_data,w)
        log_obj.info("account:%s   action:%s    amount:%s   interest:%s" %
                     (acc_data['id'], tran_type, amount, interest))
        return acc_data
    else:
        print("\033[31;1mTransaction type [%s] is not exist!\033[0m" % tran_type)

