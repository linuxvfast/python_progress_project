__author__ = 'progress'
import sys,json,logging,os
from conf import setting
sys.path.append(setting.base_dir)

from core import auth,logger,transaction


#临时保存用户信息
user_data = {
    'account_id':None,
    'is_authenticated':False,
    #'account_data':None
}

#访问日志记录
access_logger = logger.logger('access')

#交易日志
trans_logger = logger.logger('transaction')

def withdraw(acc_data):
    '''
    提现操作
    :param acc_data: 用户信息
    :return:
    '''
    current_info = '''-------- balance info --------
    credit : %s 
    balance : %s'''%(acc_data['credit'],acc_data['balance'])
    print(current_info)
    current_balance = acc_data['balance']
    while True:
        get = input('返回(b),提现请输入金额>>>')
        if get == 'b':
            break
        if len(get) > 0 and get.isdigit():
            new_balance = transaction.make_transaction(trans_logger,acc_data,'withdraw',get)
            # print('new_balance in the get_money:',new_balance)
            if new_balance:
                print('''Remaining Balance:%s''' % (new_balance['balance']))
        else:
            print('[%s] is not a valid amount, only accept integer!' % get)
            continue

def transfer(acc_data):
    '''
    转账操作
    :param acc_data:
    :return:
    '''
    current_info = '''-------- balance info --------
        credit : %s 
        balance : %s''' % (acc_data['credit'], acc_data['balance'])
    print(current_info)
    current_balance = acc_data['balance']
    while True:
        get = input("返回(b),转账请输入用户ID和金额('1111',100)>>>").strip()
        if get == 'b':
            break
        new_get = get.strip('()').split(',')
        # print(new_get[0])
        # print(new_get[1])
        if len(new_get[1]) > 0 and new_get[1].isdigit():
            new_balance = transaction.make_transaction(trans_logger, acc_data, 'transfer', new_get[1])
            if new_balance:
                #Update collect money the user information
                with open('%s/%s.json'%(setting.file_dir,new_get[0]),'r',encoding='utf-8') as rf,\
                        open('%s/%s.json_bak'%(setting.file_dir,new_get[0]),'w',encoding='utf-8') as wf:
                    other_balance =json.load(rf)
                    other_balance['balance'] += float(new_get[1])
                    json.dump(other_balance,wf)
                print('user [%s] received [%s] money'%(new_get[0],new_get[1]))
                print('''Remaining Balance:%s''' % (new_balance['balance']))
                os.remove('%s/%s.json'%(setting.file_dir,new_get[0]))
                os.rename('%s/%s.json_bak'%(setting.file_dir,new_get[0]),'%s/%s.json'%(setting.file_dir,new_get[0]))
        else:
            print('[%s] is not a valid amount, only accept integer!' % new_get[1])
            continue

def repay(acc_data):
    '''
    还款操作
    :param acc_data: 用户信息
    :return:
    '''
    current_info = '''-------- balance info --------
        credit : %s 
        balance : %s''' % (acc_data['credit'], acc_data['balance'])
    print(current_info)
    current_balance = acc_data['balance']
    while True:
        get = input('返回(b),还款请输入金额>>>')
        if get == 'b':
            break
        if len(get) > 0 and get.isdigit():
            new_balance = transaction.make_transaction(trans_logger, acc_data, 'repay', get)
            if new_balance:
                print('''Remaining Balance:%s''' % (new_balance['balance']))
        else:
            print('[%s] is not a valid amount, only accept integer!' % get)
            continue

def bill_info(acc_data):
    '''
    查询交易的账单信息
    :param acc_data:
    :return:
    '''
    # print(acc_data)
    sql_id = acc_data['id']
    print(sql_id)
    print(type(sql_id))
    with open('%s/%s'%(setting.log_dir,setting.LOG_TYPES['transaction']),'r',encoding='utf-8') as f:
        for i in f:
            line = i.strip().split()
            # print(line)
            new = line[7].split(':')[1]
            # print(new)
            if new == sql_id:
                print(line)

def account_info(acc_data):
    '''
    显示登录用户的账号信息
    :param user_data: 账号信息
    :return:
    '''
    print('登录账号信息如下'.center(20,'*'))
    for k,v in acc_data.items():
        if type(v) == int:
            print(k+': '+str(v))
        else:
            print(k,v)

def interactive(acc_data):
    '''
    功能分发器
    :param acc_data: 用户信息
    :return:
    '''
    while True:
        print('''
==========atm机==========
    1. 提现
    2. 转账
    3. 还款
    4. 账单
    5. 账号信息
    6. 退出''')
        dict_func = {
            '1': withdraw,
            '2': transfer,
            '3': repay,
            '4': bill_info,
            '5': account_info,
            '6': exit,
        }

        choice = input('>>>')
        try:
            dict_func[choice](acc_data)
        except KeyError as e:
            continue

def run():
    acc_data = auth.acc_login(user_data, access_logger)
    print('acc_data',acc_data)
    if user_data['is_authenticated']:
        # user_data['account_data'] = acc_data
        interactive(acc_data)  # 用户交互


