__author__ = 'progress'

import os,sys,logging

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
file_dir = '%s/db'%base_dir
log_dir = '%s/log'%base_dir

LOG_LEVEL = logging.INFO
LOG_TYPES = {
    'transaction': 'transactions.log',
    'access': 'access.log',
}

TRANSACTION_TYPE = {
    'repay':{'action':'plus', 'interest':0}, #还款
    'withdraw':{'action':'minus', 'interest':0.05}, #取款
    'transfer':{'action':'minus', 'interest':0.05}, #转账
    'consume':{'action':'minus', 'interest':0},  #购物
}