__author__ = 'progress'
import os,sys
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
from conf import setting
import json
filname = '0001.json'
acc_dic = {
    'id': '0001',
    'password': 'abc',
    'credit': 15000,
    'balance': 15000,
    'enroll_date': '2016-01-02',
    'expire_date': '2021-01-01',
    'pay_day': 22,
    'status': 0 # 0 = normal, 1 = locked, 2 = disabled
}
with open('%s/%s'%(setting.file_dir,filname),'w',encoding='utf-8') as f:
    json.dump(acc_dic,f)